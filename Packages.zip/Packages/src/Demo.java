//import other.tools.AdvCalc;
import other.tools.*;

import java.util.ArrayList;


public class Demo {
    public static void main(String[] args) {
        Calc obj = new Calc();
        AdvCalc obj1 = new AdvCalc();
    }
}
