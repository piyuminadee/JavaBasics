package other.tools;

public class AdvCalc {

}
