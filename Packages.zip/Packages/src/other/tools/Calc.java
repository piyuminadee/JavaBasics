package other.tools;

public class Calc {
}
